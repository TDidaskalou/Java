/**
 * 
 */
/**
 * 
 */
module ContainersAssignment {
	requires java.desktop;
}